package com.codewithgolap.signinproviders;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    FirebaseAuth mAuth;
    FirebaseUser currentUser ;
    private Button order,readdata;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        order= findViewById(R.id.order);
        readdata = findViewById(R.id.readdata);
        order.setOnClickListener(ls);
        readdata.setOnClickListener(ls);



        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(Html.fromHtml("<font color=\"black\">"+getString(R.string.profile)+"</font>"));
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // ini
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        userData();
    }

    public void userData() {
        CircleImageView userImage = findViewById(R.id.userImage);
        TextView userName = findViewById(R.id.userName);
        TextView userEmail = findViewById(R.id.userEmail);

        userName.setText(currentUser.getDisplayName());
        userEmail.setText(currentUser.getEmail());

        if (currentUser.getPhotoUrl() != null){
            Glide.with(this).load(currentUser.getPhotoUrl()).into(userImage);
        }
        else {
            Glide.with(this).load(R.drawable.avatarr).into(userImage);
        }
    }

    public void logout(View view) {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(getApplicationContext(),EmailAndPasswordLoginActivity.class);
        startActivity(intent);
        finish();
    }
    private  Button.OnClickListener ls =new Button.OnClickListener()
    {
        public  void onClick(View v)
        {
            switch(v.getId())
            {
                case R.id.order: //跳轉點餐
                    Intent intent=new Intent();
                    intent.setClass(MainActivity.this,.class);
                    startActivity(intent);


                case R.id.readdata: //跳轉天氣
                    Intent intent1=new Intent();
                    intent1.setClass(MainActivity.this,.class);
                    startActivity(intent1);


            }

        }

    };
}